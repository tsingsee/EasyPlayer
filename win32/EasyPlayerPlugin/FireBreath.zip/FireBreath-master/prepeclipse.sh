#!/bin/bash -ef

GEN='Eclipse CDT4 - Unix Makefiles'

source ${0%/*}/prepmake.sh "$@"
