This "installer" is incomplete, but it could be a useful resource for
you.
