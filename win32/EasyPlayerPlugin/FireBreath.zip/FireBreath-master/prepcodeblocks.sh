#!/bin/bash -ef

GEN='CodeBlocks - Unix Makefiles'

source ${0%/*}/prepmake.sh "$@"
